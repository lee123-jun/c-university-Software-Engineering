#include <iostream>
#include <fstream>
#include <algorithm> // std::fill
#include <windows.h> // std::fill
#include <sstream> // stringstream iss iss�� ���忡�� ���鹮�ڸ� �������� ���� 

using namespace std;

void Init(int megabytes);
char Flash_read(int);
void Flash_write(int, char);
void Flash_erase(int);
void Flash_print(void); // ��ü flash memory ���
void Flash_save();

void Print_table();
void FTL_read();
void FTL_write();

char *PSN; // flash memory �迭
int sector; // SECTOR ����
int block; // BLOCK ����

void Init(int mb) {
	sector = mb*1024*1024/512; // sector ���� ���
	block = sector/32; // block ���� ���
	cout<<"sector: "<<sector<<"/ block: "<<block<<endl;
	PSN = new char[sector];
	fill(PSN, PSN + sector, '\0'); // ��ü sector \0�� �ʱ�ȭ
}

char Flash_read(int psn) {
	stringstream ss;
	string str;
	int token_idx;
	char token_value;
	ifstream readfile;
	readfile.open("flashmemory.txt");
	
	for(int i=0;i<sector; i++){
		getline(readfile, str);
		ss.str(str);
		ss>>token_idx;
		ss>>token_value;
		Sleep(500);
		cout<<"idx: "<<token_idx<<"value: "<<token_value<<endl;
		PSN[i] = token_value;
	}
	
	for(int i=0; i<sector; i++){
		cout<<i<<": "<<PSN[i]<<endl;
	}
	
	if(psn > sector) {
		cout<<"error over the full range"<<endl;
		return -1;
	}
	if(PSN[psn]=='\0') {
		cout<<"error this element is empty"<<endl;
		return -1;
	}

	readfile.close();
	return PSN[psn];
}

void Flash_write(int psn, char value) {
	ofstream writefile;
	writefile.open("flashmemory.txt");

	if(PSN[psn] != '\0') {
		cout<<"error cannot be write that location..."<<endl;
		return;
	}
	PSN[psn] = value;
	cout<<psn<<" ��ġ�� "<<value<<" �� ���ԿϷ�."<<endl;

	for(int i=0; i<sector; i++) { // sector ���
		writefile << i << " " << PSN[i] << endl;
	}

	writefile.close();
	cout<<"save complete !"<<endl;
}

void Flash_erase(int choice) {
	ofstream writefile;
	writefile.open("flashmemory.txt");
	for(int i=choice*32; i<choice*32+32; i++) {
		PSN[choice+i] = '\0';
	}

	for(int i=0; i<sector; i++) {
		writefile<<i<<PSN[i]<<endl;
	}
	writefile.close();
	cout<<"save complete !"<<endl;
}

void Flash_print() {
	cout<<"=== PSN ==="<<endl;
	cout<<"sector | value"<<endl;
		for(int j=0; j<sector; j++) { // sector ���
		if(PSN[j] != '\0') {
			cout<<j<<"        "<<PSN[j]<<endl;
		}
	}
}

void FTL_write(){
	
}

void FTL_read(){
	
}

void Print_table(){
	
}

int main(void) {
	int choice; // switch��
	int mb; // flash memory capacity
	int psn; // psn(�����ϰ����ϴ� ��ġ)�Է�
	char value;

	cout<<"input flash memory capacity(MB)"<<endl;
	cout<<"MB: ";
	cin>>mb;

	Init(mb);

	while(1) {
		cout<<"=== file system ==="<<endl;
		cout<<"[1] write"<<endl;
		cout<<"[2] read"<<endl;
		cout<<"[3] erase"<<endl;
		cout<<"[4] print"<<endl;
		cout<<"[0] exit"<<endl;
		cout<<"choice: ";
		cin>>choice;

		switch(choice) {
			case 1: // write
				cout<<"input psn: ";
				cin>>psn;
				cout<<"input value: ";
				cin>>value;
				Flash_write(psn, value);
				break;
			case 2: // read
				cout<<"input psn: ";
				cin>>psn;
				cout<<psn<<": "<<Flash_read(psn)<<endl;
				break;
			case 3: // erase
				cout<<"=== PSN ==="<<endl;
				cout<<"sector | value"<<endl;
				for(int j=0; j<sector; j++) { // sector ���
					if(PSN[j] != '\0') {
						cout<<j<<"     "<<PSN[j]<<endl;
					}
				}
				cout<<"(Blocks start from zero.)"<<endl;
				cout<<"enter the block you want to delete: ";
				cin>>choice;
				Flash_erase(choice);
				break;
			case 4: // print
				Flash_print();
				break;
			case 0:
				cout<<"exit the program"<<endl;
				return 0;
			default:
				cout<<"wrong input"<<endl;
		}
	}

	return 0;
}
